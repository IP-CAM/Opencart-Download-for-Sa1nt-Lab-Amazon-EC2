[OpenCart homepage](http://www.opencart.com/) | 
[OpenCart forums](http://forum.opencart.com/) | 
[OpenCart blog](https://www.opencart.com/index.php?route=cms/blog) | 
[How to documents](http://docs.opencart.com/) | 
[Newsletter](http://newsletter.opencart.com/h/r/B660EBBE4980C85C)

***

OpenCart is created under the [GNU General Public License version 3 (GPLv3)](https://github.com/opencart/opencart/blob/master/license.txt)